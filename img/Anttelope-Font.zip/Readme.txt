Hello,

Thank for purchasing and using Anttelope.

How to Enable OpenType Features in Word, Photoshop and Illustrator

https://medialoot.com/blog/how-to-enable-opentype-features-in-word-photoshop-and-illustrator/

How to Using Special Characters

https://helpx.adobe.com/illustrator/using/special-characters.html

Thanks,


Creatype Studio
https://creatypestudio.co